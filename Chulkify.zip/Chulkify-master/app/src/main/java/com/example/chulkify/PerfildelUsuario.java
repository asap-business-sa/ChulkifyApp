package com.example.chulkify;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PerfildelUsuario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfildel_usuario);
    }
}