package com.example.chulkify.login.no_usados;

import androidx.fragment.app.Fragment;

import com.android.volley.Response;

import org.json.JSONObject;

public class Adapter_ini_login extends Fragment implements Response.Listener<JSONObject> {




    @Override
    public void onResponse(JSONObject response) {

    }
}
