package com.example.chulkify.login.no_usados;

public class Adapter_registro {
}
